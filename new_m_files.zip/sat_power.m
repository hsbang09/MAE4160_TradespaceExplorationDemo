function sat_out = sat_power(sat_in)

% sat_power
%   sat_out = sat_power(sat_in);
%
%   Function to model the CRISIS-sat power subsystem.  
%
%
%   Jared Krueger <jkrue@mit.edu>
%
%   3 Nov 2008
wgs84data;
global Deg Rad MU RE OmegaEarth SidePerSol RadPerDay SecDay Flat EEsqrd ... 
       EEarth J2 J3 J4 GMM GMS AU HalfPI TwoPI Zero_IE Small Undefined
global SolarFlux LightSpeed EarthMagneticMoment gravity k_Boltzmann

% ---------------------
% Unpackage sat struct power requirements
% ---------------------

% adcs
P_adcs      = sat_in.PowerADCS;


% optical
P_payload   = sat_in.PowerOptics;
%300 Watts?

% comm
P_comm      = sat_in.PowerComm;

% orbits
h           = sat_in.Altitude;
rho         = sat_in.Rho;
period      = sat_in.Period;  % in minutes
Life        = sat_in.Lifetime;  % in years
%Insert other power requirements here

% Calculate power requirements during daylight and eclipse
%Pd = 110;
Pd = P_adcs + P_payload + P_comm;
Pe = Pd;

% Calculate time in daylight and eclipse
Bs  = 25*Rad;
rho = rho*Rad;
phi = 2*acos(cos(rho)/cos(Bs));
Te  = period*(phi/(2*pi));
Td  = period - Te;

% Determine path efficiencies
Xd  = .8;
Xe  = .6;

% ----------------------
% Compute model outputs
% ----------------------
% First estimate how much power solar arrays must produce
Psa = (Pe*Te/Xe + Pd*Td/Xd)/Td;

% Select type of solar cell and estimate size (for normal sun
% angle)
%Si = 202 W/m^2; 3.75% degradation/yr
%GaAs = 253 W/m^2; 2.75% per yr
%Multi = 301 W/m^2; 0.5% per yr

Pbol = 301*.77*cos(23.5*Rad);
Ld   = (1-.005)^Life;
Peol = Pbol*Ld;
Asa  = Psa/Peol;

%Determine battery design
DoD = .5; %NiH2 10k cycles
N = 3;  %# of batteries
n = .9;
Cr = Pe*(Te/60)/(DoD*N*n);

%Mass Estimates
Msa = .04*Psa*pi;  %for cylindrical body-mounted
Mbatt = Cr/45;
Mpcu = .02*Psa;

Mpower = Msa + Mbatt + Mpcu;  % in kg

% --------------------------
% Package output sat struct
% --------------------------
sat_out = sat_in;           % copy existing fields into updated struct
sat_out.SolarArrayPower = Psa;
sat_out.SolarArrayArea = Asa;
sat_out.MassPower = Mpower;
sat_out.Power = Pd;

return;