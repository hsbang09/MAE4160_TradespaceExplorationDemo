function [sat] = sat_initialize()

% sat_initialize
%   sat = sat_initialize;
%
%   Function to create a sat structure and initialize to default valus.

% --------------------------
% Constants
% --------------------------
global Deg Rad MU RE OmegaEarth SidePerSol RadPerDay SecDay Flat EEsqrd ... 
       EEarth J2 J3 J4 GMM GMS AU HalfPI TwoPI Zero_IE Small Undefined
global SolarFlux LightSpeed EarthMagneticMoment gravity k_Boltzmann


wgs84data;
SolarFlux           = 1367;             % Solar flux [W/m^2]
LightSpeed          = 3.0E8;            % Light speed in m/s
EarthMagneticMoment = 7.96e15;          % Magnetic moment of the Earth in Tesla*m^3
gravity             = 1000*MU/(RE^2);   % gravity on the Earth in m/s^2
k_Boltzmann         = 1.37E-23;         % Boltzmann Constant


% --------------------------
% User-defined inputs
% --------------------------

% system
sat.Lifetime        = 5;            % satellite lifetime in years

% structure
sat.Ixx             = 90;
sat.Iyy             = 60;
sat.Izz             = 90;

% orbital
sat.Altitude        = 567;          % orbit altitude    [km]
sat.Inclination     = 98;           % orbit inclination [deg]
sat.Eccentricity    = 0;            % orbit eccentricity [#]
sat.Nsats           = 4;            % total number of satellites [#]
sat.Nplanes         = 2;            % number of planes
sat.MaxPointing     = 20;           % maximum pointing angle from nadir [deg]

% optical
sat.GResOff         = 1;            % ground resolution at max off-nadir angle  [m]
sat.Wavelength      = 500e-9;       % observation wavelength [m]
sat.NPixVelocity    = 2;            % number of CCD pixels along the velocity direction [#]
sat.NPixCrosstrack  = 2000;         % number of CCD pixels along the crosstrack direction [#]
sat.PixelSize       = 50e-6;        % size of pixels in the CCD [m]
sat.Nbits           = 12;           % detector quantization [#]
sat.SamplingFactor  = 2;            % number of pixels per gound resolution [#]
sat.Fnumber         = 2;            % F number (f/D) [#]
sat.ArealDensity    = 30;           % Primary mirror areal density [kg/m^2]

% ADCS
sat.MaxDeviation    = 1;            % Max allowable deviation from nadir pointing [deg]
sat.SurfaceArea     = 3;            % Surface area [m^2]
sat.Reflectance     = 0.6;
sat.MaxSolarAngle   = 0;            % Worst-case solar incidence angle [deg]
sat.OffsetCPsolar   = 0.3;
sat.OffsetCPaero    = 0.2;
sat.ResidualDipole  = 1;
sat.DragCoefficient = 2;
sat.MaxSlewAngle    = 2*sat.MaxPointing;% Max slew angle in deg
sat.MaxSlewTime     = 60;              % Max time in s allowed to slew MaxSlewAngle
sat.RWMarginFactor          = 1.5;
sat.ThrusterMomentArm       = 0.5;
sat.DumpingPulseDuration	= 1;        % [s]
sat.DumpingPulseFrequence   = 1;        % dumping pulses/(wheel and day)
sat.NumberofRW              = 4;
sat.NumberofSunSensors      = 3;
sat.NumberofMagnetometers   = 2;
sat.NumberofMagneticTorquers= 3;
sat.SlewingPulseDuration	= 3;        % [s]
sat.SlewingPulseFrequence   = 52/365;   % slewing pulses/(axis and day)
sat.ADCSSpecificImpulse     = 200;      % specific impulse in s

% Comm
%   Uplink
sat.ULRequiredEbN0              = 12;           % Uplink Required Energy per Bit to Noise Spectral Density in dB
sat.ULEbN0Margin                = 20;           % Uplink Margin : Eb/No - Eb/N0 required
sat.ImplementationLoss          = 2;            % Implementation Loss in dB
sat.ULTXPower                   = 1.0;          % Uplink Transmitter Power in W
sat.ULTXAntennaGain             = 30;           % Uplink Transmitter Antenna Gain in dB
sat.ULTXLineLoss                = -1.0;         % Uplink Transmitter Power in dB
sat.GroundAntennaMinElevation   = 10;           % Ground Antenna minimum elevation in deg
sat.ULFrequency                 = 2.0E9;        % Uplink Frequency in Hz
sat.ULTXAntennaDiameter         = 2.0;          % Uplink Transmitter Antenna Diameter in m
sat.ULDataRate                  = 100;          % Uplink Data rate in bps
sat.ULTXAntennaPointingOffset   = 0.2;          % Uplink Transmitter Antenna Pointing Offset in deg
sat.ULRXAntennaEfficiency       = 0.55;         % Uplink Receiver Antenna Efficiency
sat.TTCRedundancy               = 2;            % Number of elements of each (antenna and transponder)
%   Downlink
sat.DLRequiredEbN0              = 10.0;         % Downlink Required Energy per Bit to Noise Spectral Density in dB
sat.DLEbN0Margin                = 3.0;          % Downlink Margin : Eb/No - Eb/N0 required
sat.DLFrequency                 = 2.2e9;        % Downlink Frequency in Hz
sat.DLRXAntennaPointingOffset   = 0.2;          % Downlink Receiver Antenna Pointing Offset in deg
sat.DLRXAntennaDiameter         = 2.0;          % Downlink Receiver Antenna Diameter in m
sat.DLTXLineLoss                = -1.0;         % Downlink Transmitter Power in dB
sat.ImagesPerDay                = 1;            % Number of images to transmit per day
sat.DLDataRate                  = 8e6;          % Downlink Data Rate

% ground station
sat.NGroundStations             = 2;            % number of ground stations
sat.LatGroundStations           = [37.9455 21.3161]; 
sat.LonGroundStations           = [-75.4611 -157.8864];
sat.AngleGroundStations         = 21/(sat.ULFrequency/10^9)/sat.ULTXAntennaDiameter;

% -------------------------------------------------------------------------
% Computed outputs
% -------------------------------------------------------------------------

% orbits
sat.Semimajor       = [];           % semimajor axis    [m]
sat.Velocity        = [];           % orbital velocity  [m/s]
sat.VelocityPer     = [];           % velocity at perigee [m/s]
sat.VelocityApo     = [];           % velocity at apogee [m/s]
sat.Period          = [];           % orbital period [s]
sat.Density         = [];           % atmospheric density at altitude [kg/km^3]
sat.MeanAngMotion   = [];           % mean angDLar motion, n [rad/s]
sat.Rho             = [];           % angular radius [deg]
sat.Epsilon         = [];           % elevation angle of ground target [deg]
sat.Lambda           = [];          % earth central angle [deg]
sat.Range           = [];           % range to target [km]
sat.CoverageWidth   = [];           % coverage width [km]

% ADCS
 %%% Disturbances
sat.TorqueGravity   = [];       % Disturbance Torque due to gravity gradient in Nm
sat.TorqueMagnetic  = [];       % Disturbance Torque due to gravity gradient in Nm
sat.TorqueSolar     = [];
sat.TorqueAero      = [];
sat.MaxTorque       = [];
 %%% Actuators: Reaction Wheels
sat.RWTorque        = [];
sat.RWMomentum      = [];
sat.RWMaxOmega      = [];
 %%% Actuators: Magnetic Torquers
sat.MagneticTorque  = [];
sat.MGTorquersDipole= [];
 %%% Actuators: Thrusters
sat.ThrusterForce   = [];
sat.ThrusterNpDLses = [];
sat.ADCSDelta_V     = [];
sat.ADCSDelta_VD    = [];
sat.ADCSDelta_VS    = [];
sat.ADCDVS_VT       = [];
sat.ADCSPropellantMass = [];
sat.MassADCS        = [];
sat.PowerADCS       = [];

% optical
sat.Aperture        = [];       % primary mirror aperture diameter [m]
sat.Flength         = [];       % focal length                              [m]
sat.FOVc            = [];       % instrument cross track field of view      [deg]
sat.FOVv            = [];       % instrument velocity vector field of view  [deg]
sat.GResNadir       = [];       % ground resolution at nadir                [m]
sat.SwathWidthNad   = [];       % swath width at nadir                      [km]
sat.SwathWidthOff   = [];       % swath width at eta                        [km]
sat.DataVolume      = [];       % number of bits per image                  [#]
sat.MassOptics      = [];       % mass of the optical subsystem             [kg]
sat.PowerOptics     = [];       % power of the optical subsystem            [W]

% comm
sat.ULRXAntennaDiameter     = [];	% Uplink Receiver Antenna Diameter in m
sat.ULRXAntennaGain         = [];	% Uplink Receiver Antenna Gain
sat.ULRXAntennaBeamwidth    = [];	% Uplink Receiver Antenna Beamwidth in deg
sat.DLTXPower               = [];	% Downlink Transmitter Power in W
sat.DLTXAntennaBeamwidth    = [];	% Downlink Transmitter Antenna Beamwidth in deg
sat.DLTXAntennaGain         = [];	% Downlink Transmitter Antenna Gain
sat.DLTXAntennaDiameter     = [];	% Downlink Transmitter Antenna Diameter in m
sat.MassComm                = [];   % Mass of the communications subsystem  [kg]
sat.PowerComm               = [];   % Power of the communications subsystem [W]

% power
sat.MassPower       = [];       % Mass of the power subsuystem  [kg]
sat.SolarArrayPower = [];       % Power generated by the solar arrays [W]
sat.SolarArrayArea  = [];       % Area of the solar arrays      [m^2]

% thermal
sat.MassThermal     = 7;
sat.PowerThermal    = 5;

% propulsion
sat.MassProp    = 8;
sat.PowerProp    = 1;

% structure
sat.Volume          = [];
sat.Inertia         = [];
% system
sat.Mass            = [];           % spacecraft mass [kg]
sat.Cost            = [];           % spacecraft system cost estimate [$]
sat.Power           = [];           % spacecraft power use [W]

% STK
sat.CoverageTime        = [];          % time to achieve 100% coverage [min]
sat.FinalCoverage       = [];          % coverage at end of simulation period
sat.RevisitTimeMax      = [];          % maximum revisit time [min]
sat.RevisitTimeMean     = [];          % mean revisit time [min]
sat.ResponseTimeMax     = [];          % maximum revisit time [min]
sat.ResponseTimeMean    = [];          % mean revisit time [min]
sat.TotalNImagesDay     = [];          % Total number of images per day for the whole system
sat.CommDurationMax     = [];          % Max Duration of the communication link between GS and satellites
sat.CommDurationMean    = [];          % Mean Duration of the communication link between GS and satellites
sat.CommDurationMin     = [];          % Min Duration of the communication link between GS and satellites
sat.CommDurationMin     = [];          % Total Duration of the communication link between GS and satellites
sat.CommRespTimeMax     = [];          % Max Response time for the satellites with the ground stations
sat.CommRespTimeMean    = [];          % Mean Response time for the satellites with the ground stations
return;
% end sat_initialize.m