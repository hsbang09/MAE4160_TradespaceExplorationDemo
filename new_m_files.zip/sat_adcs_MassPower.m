function sat_out = sat_adcs_MassPower(sat_in)

% sat_adcs_MassPower
%   sat = sat_adcs_MassPower(sat);
%
%   Function to model the mass and power of the ADCS.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Unpackage Inputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
torque                  = sat_in.RWTorque;
momentum                = sat_in.RWMomentum;
dipole                  = sat_in.MGTorquersDipole;
N_MGT                   = sat_in.NumberofMagneticTorquers;
N_RW                    = sat_in.NumberofRW;
N_SS                    = sat_in.NumberofSunSensors;
N_MM                    = sat_in.NumberofMagnetometers;

MF                      = 1.5;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Actuators
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Reaction wheel
RW_Mass = 1.5*momentum.^0.6;
RW_Power = 200*torque;

% Magnetic torquers
%COTS_MGT(i,:) =  [Dnom Dmax  Mass Lengt Pow];
COTS_MGT(1,:)   = [5.00 100.0 .750 0.282 0.5];
COTS_MGT(2,:)   = [15.0 19.00 .450 0.228 2.9];
COTS_MGT(3,:)   = [40.0 45.00 .900 0.338 3.1];
found2 = 0;
for i =1:size(COTS_MGT,1)
    if dipole*MF<COTS_MGT(i,1)
        MGT_Mass    = COTS_MGT(i,3);
        %MGT_Length  = COTS_MGT(i,4);
        MGT_Power   = COTS_MGT(i,5);
        found2 = 1;
        break;
    end    
end
if found2 == 0
    MGT_Mass    = 1.0;
    MGT_Power   = 3.5;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensors
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Magnetometers
m_MM = 0.185;
P_MM = 0.6;

% Sun Sensors

m_SS = 0.05;
P_SS = 0.25;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Others: wiring, etc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
m_others = 1.0;
P_others = 0.25;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Assing outputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sat_out                 = sat_in;
sat_out.MassADCS        = N_RW.*RW_Mass+N_MGT.*MGT_Mass+N_SS*m_SS + N_MM*m_MM+m_others;
sat_out.PowerADCS       = N_RW.*RW_Power+N_MGT.*MGT_Power+N_SS*P_SS + N_MM*P_MM + P_others;

return;