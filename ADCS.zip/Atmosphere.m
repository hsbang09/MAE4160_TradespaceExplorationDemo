function rho = Atmosphere(h)
% Calculates rho as a function of h i
rho0 = 1E-05;
H = 36915;
h0 = 85E03;

rho = rho0*exp(-(h-h0)./H);