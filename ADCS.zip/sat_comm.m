function sat_out = sat_comm(sat_in)

% sat_comm
%   sat = sat_comm(sat);
%
%   Function to model the CRISIS-sat TT&C system.

% unpackage sat struct
% call internal functions
sat1 = sat_in;
sat2 = sat_adcs_disturbances(sat1);
sat3 = sat_adcs_actuators(sat2);
%[sat4] = sat_adcs_sensors(sat3);

% assign model outputs
sat_out = sat3;
return;