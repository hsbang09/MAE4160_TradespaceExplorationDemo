function sat_out = sat_orbit(sat_in)

% sat_orbit
%   sat = sat_orbit(sat);
%
%   Function to model the CRISIS-sat orbital parameters
global   MU RE OmegaEarth SidePerSol RadPerDay SecDay Flat EEsqrd ... 
       EEarth J2 J3 J4 GMM GMS AU HalfPI TwoPI Zero_IE Small Undefined


% unpackage sat struct
h = sat_in.Altitude;

% call internal functions
R = 1000*(RE+h);
V = OrbitVelocity(R,R);%a=R, r=R (assuming e=0)
muE = MU*1e9;
n = sqrt(muE./R.^3);
P = TwoPI./n;
rho = Atmosphere(1000*h);

% assign model outputs
sat_out = sat_in;
sat_out.Velocity = V;
sat_out.Density = rho;
sat_out.Period = P;
sat_out.MeanAngMotion = n;
return;