% Plots the dependence of the GG disturbance torque with the orbit altitude
initConstants;

%Input parameters
%As=3;
q = 0.6;
i = 0; % minimum angle, max perturbation
cps_cg = 0.3;

%X Variable:
a = [0.5:0.1:2.0];
b = [0.5:0.1:2.0];
As = a.*b;

Tsp = SPDisturbanceTorque (As, q, i, cps_cg)

plot(As,Tsp);
title(['Solar Pressure DT vs Surface Area, q = ', num2str(q), ', i = ',num2str(i),', cps-cg = ',num2str(cps_cg)]);
xlabel(' Surface area (m^2)');
ylabel(' SP Disturbance Torque (N*m)');

