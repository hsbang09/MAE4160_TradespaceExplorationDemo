function sat_out = sat_optics(sat_in)

% sat_optics
%   sat = sat_optics(sat);
%
%   Function to model the CRISIS-sat optical system.


% unpackage sat struct
lambda  = sat_in.Wavelength;
D       = sat_in.Aperture;

% compute model outputs
sat_out.resolution = lambda/D;


return;