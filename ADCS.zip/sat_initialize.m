% sat_initialize
%
% Initialize model with input values


% --------------------------
% Constants
% --------------------------
global Deg Rad MU RE OmegaEarth SidePerSol RadPerDay SecDay Flat EEsqrd ... 
       EEarth J2 J3 J4 GMM GMS AU HalfPI TwoPI Zero_IE Small Undefined
global SolarFlux LightSpeed EarthMagneticMoment gravity
global sat

wgs84data;
SolarFlux           = 1367;         % Solar flux [W/m^2]
LightSpeed          = 3.0E8;        % Light speed in m/s
EarthMagneticMoment = 7.96e15;      % Magnetic moment of the Earth in Tesla*m^3
gravity             = 1000*MU/(RE^2);    % gravity on the Earth in m/s^2


% --------------------------
% User-defined inputs
% --------------------------

% system
sat.Lifetime        = 5;            % satellite lifetime in years

% structure
sat.Ixx             = 90;           %
sat.Iyy             = 60;
sat.Izz             = 90;

% orbital
sat.Altitude        = 700;          % orbit altitude    [km]
sat.Inclination     = 98;           % orbit inclination [deg]
sat.Eccentricity    = 0;            % orbit eccentricity [#]
sat.RAAN            = [];           % right ascention of the ascending node [deg]          
sat.ArgPerigee      = [];           % argument of perigee [deg]
sat.Nplanes         = 2;            % number of orbit planes [#]
sat.AnglePlanes     = 90;           % angle between orbit planes [deg]
sat.Nsats           = 4;            % number of sats per plane [#]

% optical
sat.Aperture        = 1;            % primary mirror aperture diameter [m]
sat.Wavelength      = 500e-9;       % observation wavelength [m]
sat.MaxPointing     = 20;           % maximum pointing angle [m]
sat.ArraySize       = 6000;         % number pixels across the CCD array [#]
sat.Fnumber         = 2;            % F number (f/D) [#]

% ADCS
sat.MaxDeviation    = 1;            % Max deviation from nadir pointing [deg]
sat.SurfaceArea     = 3;            % Surface area [m^2]
sat.Reflectance     = 0.6;
sat.MaxSolarAngle   = 0;            % Worst-case solar incidence angle [deg]
sat.CPsolar         = [];
sat.CPaero          = [];
sat.OffsetCPsolar   = 0.3;
sat.OffsetCPaero    = 0.2;
sat.ResidualDipole  = 1;
sat.DragCoefficient = 2;
sat.MaxSlewAngle    = 30;               % Max slew angle in deg
sat.MaxSlewTime     = 60;               % Max time in s allowed to slew MaxSlewAngle
sat.RWMarginFactor          = 1.5;
sat.ThrusterMomentArm       = 0.5;
sat.DumpingPulseDuration	= 1;        % [s]
sat.DumpingPulseFrequence   = 1;        % dumping pulses/(wheel and day)
sat.NumberofRW              = 3;
sat.SlewingPulseDuration	= 3;        % [s]
sat.SlewingPulseFrequence   = 12/365;   % slewing pulses/(axis and day)
sat.ADCSSpecificImpulse     = 200;      % specific impulse in s

% Comm
sat.DownLinkfrequency       = 2.2E9;        % Downlink Frequency in Hz
sat.UpLinkFrequency         = 2.0E9;        % Uplink Frequency in Hz



% --------------------------
% Computed outputs
% --------------------------

% system
sat.Mass            = [];           % spacecraft mass [kg]
sat.Cost            = [];           % spacecraft system cost [$]
sat.Power           = [];           % spacecraft power use [W]
sat.Reliability     = [];           % spacecraft 1-year relability [%]

% orbits
sat.Semimajor   = [];           % semimajor axis    [m]
sat.Velocity    = [];           % orbital velocity  [m/s]
sat.VelocityPer = [];           % velocity at perigee [m/s]
sat.VelocityApo = [];           % velocity at apogee [m/s]
sat.Period      = [];           % orbital period [s]
sat.RevisitTime = [];           % time between passes over a given location [s]
sat.Density     = [];           % atmospheric density at altitude [kg/km^3]
sat.MeanAngMotion = [];         % mean angular motion, n [rad/s]

% ADCS
 %%% Disturbances
sat.TorqueGravity   = [];       % Disturbance Torque due to gravity gradient in Nm
sat.TorqueMagnetic  = [];       % Disturbance Torque due to gravity gradient in Nm
sat.TorqueSolar     = [];
sat.TorqueAero      = [];
sat.MaxTorque       = [];
 %%% Actuators: Reaction Wheels
sat.RWTorque        = [];
sat.RWMomentum      = [];
sat.RWMaxOmega      = [];
 %%% Actuators: Magnetic Torquers
sat.MagneticTorque  = [];
sat.MGTorquersDipole= [];
 %%% Actuators: Thrusters
sat.ThrusterForce   = [];
sat.ThrusterNpulses = [];
sat.ADCSDeltaV      = [];
sat.ADCSPropellantMass = [];

% optical
sat.Flength         = [];
sat.GResNadir       = [];       % ground resolution at nadir [m]
sat.GResMaxSlant    = [];       % ground resolution at max slant [m]
sat.FOV             = [];       % field of view [deg]
sat.FOR             = [];       % field of regard [deg]
sat.SwathWidth      = [];       % swath width [m]
sat.CoverageWidth   = [];       % coverage width [m]
sat.MassOptical     = [];

% comm



% end sat_initialize.m