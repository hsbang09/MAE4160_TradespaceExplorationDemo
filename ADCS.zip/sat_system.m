% sat_system.m
global sat

sat_initialize;             % setup inputs

sat= sat_orbit(sat);        % orbit dynamics model
%sat = sat_optics(sat);     % optical payload model
sat = sat_adcs(sat);        % ADCS model
%sat = sat_comm(sat);       % communications subsystem model

%sat_visualize(sat);        % system visualization?
                            %   plots
                            %   STK results
                            %   field of regard illustration
                            %   simulated imagery?

