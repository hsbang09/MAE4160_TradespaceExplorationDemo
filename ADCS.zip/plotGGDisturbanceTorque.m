% Plots the dependence of the GG disturbance torque with the orbit altitude
initConstants;

%Input parameters
Iz = 90;
Iy = 60;
theta = 1;

%X Variable: altitude
h = 1000*[100:10:1000];
R = RE+h;

Tg = GGDisturbanceTorque (Iy, Iz, R, theta);

plot(h./1000,Tg);
title(['Gravity Gradient DT vs orbit altitude for Iy= ',num2str(Iy),', Iz = ',num2str(Iz),', theta= ',num2str(theta)]);
xlabel(' Orbit altitude (km)');
ylabel(' GG Disturbance Torque (N*m)');
