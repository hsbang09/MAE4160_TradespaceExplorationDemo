function sat_out = sat_adcs_actutators_thrusters(sat_in)
% sat_adcs_actutators_thrusters
%   sat = sat_adcs_actutators_thrusters(sat);
%
%   Function to size the CRISIS-sat Thrusters.
global Deg Rad MU RE OmegaEarth SidePerSol RadPerDay SecDay Flat EEsqrd ... 
       EEarth J2 J3 J4 GMM GMS AU HalfPI TwoPI Zero_IE Small Undefined
global gravity;

% unpackage sat struct

DT          = sat_in.MaxTorque;
L           = sat_in.ThrusterMomentArm;
dtheta      = 2*sat_in.MaxPointing;
dt          = 0.5*sat_in.InTheaterAccessDuration;
fdumping    = sat_in.DumpingPulseFrequence;
fslewing    = sat_in.SlewingPulseFrequence;
Tdumping    = sat_in.DumpingPulseDuration;
Tslewing    = sat_in.SlewingPulseDuration;
Nwheels     = sat_in.NumberofRW;
life        = sat_in.Lifetime;
h           = sat_in.RWMomentum;
I           = sat_in.Izz;
Isp         = sat_in.ADCSSpecificImpulse;
% internal calculations

% Force
%   %Disturbance
FDisturb            = DT./L;
%   %Slewing
t1 = 0.05*dt;
t2 = 0.95*dt;
max_rate            = dtheta.*Rad./(t2-t1+t1/2+(dt-t2)/2);
alfa                = max_rate/t1;
FSlew               = I.*alfa./L;
%   % Momentum dumping
FDump               = h./(L*Tdumping);
%   %Worst case
vectorF             = [FSlew,FDisturb,FDump];
F                   = max(vectorF);

%Pulse life
Ndumping    = fdumping*Nwheels*365*life;
Nslewing    = 2*fslewing*2*365*life;%2 axis times maneuvers per day
Npulses     = Ndumping + Nslewing;

%DeltaV
DeltaV_dump = Ndumping*FDump*Tdumping;
DeltaV_slew = Nslewing*FSlew*Tslewing;
DeltaV      = Ndumping*FDump*Tdumping + Nslewing*FSlew*Tslewing;
%Propellant mass
MP          = DeltaV./(gravity*Isp);
% assign model outputs
sat_out                     = sat_in;
sat_out.ThrusterForce       = F;
sat_out.ThrusterNpulses     = Npulses;
sat_out.ADCSDelta_V         = DeltaV;
sat_out.ADCSDelta_VD        = DeltaV_dump;
sat_out.ADCSDelta_VS        = DeltaV_slew;
sat_out.ADCDVS_VT           = DeltaV_slew/DeltaV;
sat_out.ADCSPropellantMass  = MP;

return;